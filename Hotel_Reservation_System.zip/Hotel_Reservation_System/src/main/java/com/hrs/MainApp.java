package com.hrs;

import java.time.LocalDate;
import java.util.Scanner;

public class MainApp {

	public static void main(String[] args) {
		// Create a Scanner to read user input
		try (Scanner sc = new Scanner(System.in)) {
			// Create instance of DAO to access hotel data
			HotelDAO hotelDAO = new HotelDAO();

			while (true) {
				// Display main menu options
				System.out.println("\n----- HOTEL BOOKING/RESERVATION SYSTEM -----");
				System.out.println("1) ADD ROOM");
				System.out.println("2) ADD CUSTOMER");
				System.out.println("3) BOOK ROOM");
				System.out.println("4) VIEW AVAILABLE ROOMS");
				System.out.println("5) VIEW ALL BOOKINGS");
				System.out.println("6) CANCEL BOOKING");
				System.out.println("7) UPDATE BOOKING");
				System.out.println("8) EXIT");

				System.out.print("ENTER YOUR CHOICE: ");
				int choice = sc.nextInt();
				sc.nextLine(); // Consume newline

				switch (choice) {
				case 1:
					// Add a new room
					System.out.print("ENTER ROOM NUMBER: ");
					String roomNumber = sc.nextLine();
					System.out.print("ENTER ROOM TYPE: ");
					String type = sc.nextLine();
					System.out.print("ENTER PRICE PER NIGHT: ");
					double price = sc.nextDouble();
					sc.nextLine(); // Consume newline

					Room room = new Room();
					room.setRoomNumber(roomNumber);
					room.setType(type);
					room.setPricePerNight(price);
					room.setAvailable(true);
					hotelDAO.addRoom(room); // Save room to database
					System.out.println("ROOM ADDED SUCCESSFULLY!");
					break;

				case 2:
					// Add a new customer
					System.out.print("ENTER CUSTOMER NAME: ");
					String name = sc.nextLine();
					System.out.print("ENTER EMAIL: ");
					String email = sc.nextLine();
					System.out.print("ENTER PHONE: ");
					String phone = sc.nextLine();

					Customer customer = new Customer();
					customer.setName(name);
					customer.setEmail(email);
					customer.setPhone(phone);
					hotelDAO.addCustomer(customer); // Save customer to database
					System.out.println("CUSTOMER ADDED SUCCESSFULLY!");
					break;

				case 3:
					// Book a room
					System.out.println("AVAILABLE ROOMS:");
					hotelDAO.getAvailableRooms().forEach(System.out::println);

					System.out.print("ENTER ROOM ID TO BOOK: ");
					int roomId = sc.nextInt();
					System.out.print("ENTER CUSTOMER ID: ");
					int customerId = sc.nextInt();
					sc.nextLine(); // Consume newline

					System.out.print("ENTER CHECK-IN DATE (yyyy-MM-dd): ");
					LocalDate checkIn = LocalDate.parse(sc.nextLine());
					System.out.print("ENTER CHECK-OUT DATE (yyyy-MM-dd): ");
					LocalDate checkOut = LocalDate.parse(sc.nextLine());

					Booking booking = new Booking();
					booking.setRoom(hotelDAO.getRoomById(roomId));
					booking.setCustomer(hotelDAO.getCustomerById(customerId));
					booking.setCheckIn(checkIn);
					booking.setCheckOut(checkOut);
					booking.setTotalPrice(booking.calculateTotalPrice());

					hotelDAO.addBooking(booking); // Save booking to database
					System.out.println("ROOM BOOKED SUCCESSFULLY!");
					break;

				case 4:
					// Display all available rooms
					hotelDAO.getAvailableRooms().forEach(System.out::println);
					break;

				case 5:
					// Display all bookings
					hotelDAO.getAllBookings().forEach(System.out::println);
					break;

				case 6:
					// Cancel a booking by booking ID
					System.out.print("ENTER BOOKING ID TO CANCEL: ");
					int cancelId = sc.nextInt();
					if (hotelDAO.cancelBooking(cancelId)) {
						System.out.println("BOOKING CANCELED SUCCESSFULLY!");
					} else {
						System.err.println("BOOKING NOT FOUND.");
					}
					break;

				case 7:
					// Update check-in and check-out dates for an existing booking
					System.out.print("ENTER BOOKING ID TO UPDATE: ");
					int updateId = sc.nextInt();
					sc.nextLine(); // Consume newline
					System.out.print("ENTER NEW CHECK-IN DATE (yyyy-MM-dd): ");
					LocalDate newCheckIn = LocalDate.parse(sc.nextLine());
					System.out.print("ENTER NEW CHECK-OUT DATE (yyyy-MM-dd): ");
					LocalDate newCheckOut = LocalDate.parse(sc.nextLine());

					if (hotelDAO.updateBooking(updateId, newCheckIn, newCheckOut)) {
						System.out.println("BOOKING UPDATED SUCCESSFULLY!");
					} else {
						System.err.println("BOOKING NOT FOUND.");
					}
					break;

				case 8:
					// Exit the application
					System.out.println("YOU HAVE SUCCESSFULLY EXITED THE HOTEL RESERVATION SYSTEM. HAVE A GREAT DAY!");
					return;

				default:
					// Handle invalid choices
					System.err.println("INVALID CHOICE.");
				}
			}
		}
	}
}
