package com.hrs;

// JPA and Hibernate imports for ORM mapping
import jakarta.persistence.*;

/*
 * Entity class representing a room in the hotel reservation system.
 */
@Entity
@Table(name = "room") // Maps this entity to the 'room' table in the database
public class Room {

	@Id // Marks 'id' as the primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-generates ID values
	private int id;

	@Column(name = "room_number") // Maps 'roomNumber' to 'room_number' column
	private String roomNumber;

	private String type; // Type of room (e.g., Single, Double, Suite)

	private double pricePerNight; // Cost per night for the room

	private boolean available; // Availability status of the room

	// Getter and setter for 'id'
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	// Getter and setter for 'roomNumber'
	public String getRoomNumber() {
		return roomNumber;
	}

	public void setRoomNumber(String roomNumber) {
		this.roomNumber = roomNumber;
	}

	// Getter and setter for 'type'
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	// Getter and setter for 'pricePerNight'
	public double getPricePerNight() {
		return pricePerNight;
	}

	public void setPricePerNight(double pricePerNight) {
		this.pricePerNight = pricePerNight;
	}

	// Getter and setter for 'available'
	public boolean isAvailable() {
		return available;
	}

	public void setAvailable(boolean available) {
		this.available = available;
	}

	// Returns a string representation of the Room object
	@Override
	public String toString() {
		return "Room [id=" + id + ", roomNumber=" + roomNumber + ", type=" + type + ", pricePerNight=" + pricePerNight
				+ ", available=" + available + "]";
	}
}
