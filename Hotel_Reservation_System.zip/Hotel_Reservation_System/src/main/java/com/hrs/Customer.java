package com.hrs; // Defines the package for the Customer class

import jakarta.persistence.*; // Imports JPA annotations for ORM mapping

/*
 * Entity class representing a customer record in the database.
 */
@Entity // Declares this class as a JPA entity
@Table(name = "customer") // Maps the entity to the "customer" table
public class Customer {

	@Id // Specifies the primary key field
	@GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-increments ID using DB identity strategy
	private int id;

	private String name; // Customer name
	private String email; // Customer email
	private String phone; // Customer phone number

	// Returns customer ID
	public int getId() {
		return id;
	}

	// Sets customer ID
	public void setId(int id) {
		this.id = id;
	}

	// Returns customer name
	public String getName() {
		return name;
	}

	// Sets customer name
	public void setName(String name) {
		this.name = name;
	}

	// Returns customer email
	public String getEmail() {
		return email;
	}

	// Sets customer email
	public void setEmail(String email) {
		this.email = email;
	}

	// Returns customer phone number
	public String getPhone() {
		return phone;
	}

	// Sets customer phone number
	public void setPhone(String phone) {
		this.phone = phone;
	}

	/*
	 * Returns a string describing the customer.
	 */
	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", email=" + email + ", phone=" + phone + "]";
	}
}
