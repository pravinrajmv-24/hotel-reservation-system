package com.hrs;

import java.time.LocalDate;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HotelDAO {
	// Hibernate SessionFactory used to create sessions for database operations
	private SessionFactory sessionFactory;

	// Constructor: Configures Hibernate and builds the SessionFactory
	public HotelDAO() {
		sessionFactory = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Room.class)
				.addAnnotatedClass(Customer.class).addAnnotatedClass(Booking.class).buildSessionFactory();
	}

	// Retrieves a Room entity by its ID
	public Room getRoomById(int id) {
		try (Session session = sessionFactory.openSession()) {
			return session.get(Room.class, id);
		}
	}

	// Retrieves a Customer entity by its ID
	public Customer getCustomerById(int id) {
		try (Session session = sessionFactory.openSession()) {
			return session.get(Customer.class, id);
		}
	}

	// Persists a new Room entity to the database
	public void addRoom(Room room) {
		try (Session session = sessionFactory.openSession()) {
			session.beginTransaction();
			session.persist(room);
			session.getTransaction().commit();
		}
	}

	// Persists a new Customer entity to the database
	public void addCustomer(Customer customer) {
		try (Session session = sessionFactory.openSession()) {
			session.beginTransaction();
			session.persist(customer);
			session.getTransaction().commit();
		}
	}

	// Retrieves a list of all rooms that are marked as available
	public List<Room> getAvailableRooms() {
		try (Session session = sessionFactory.openSession()) {
			return session.createQuery("FROM Room WHERE available = true", Room.class).getResultList();
		}
	}

	// Adds a new Booking and marks the associated Room as unavailable
	public void addBooking(Booking booking) {
		try (Session session = sessionFactory.openSession()) {
			session.beginTransaction();
			booking.getRoom().setAvailable(false); // Update room availability
			session.persist(booking);
			session.getTransaction().commit();
		}
	}

	// Retrieves a list of all Bookings
	public List<Booking> getAllBookings() {
		try (Session session = sessionFactory.openSession()) {
			return session.createQuery("FROM Booking", Booking.class).getResultList();
		}
	}

	// Cancels a booking by ID and marks the associated Room as available
	public boolean cancelBooking(int bookingIdToCancel) {
		try (Session session = sessionFactory.openSession()) {
			session.beginTransaction();
			Booking booking = session.get(Booking.class, bookingIdToCancel);
			if (booking != null) {
				booking.getRoom().setAvailable(true); // Restore room availability
				session.remove(booking);
				session.getTransaction().commit();
				return true;
			}
			return false; // Booking not found
		}
	}

	// Updates the check-in and check-out dates for a booking, and recalculates
	// total price
	public boolean updateBooking(int bookingIdToUpdate, LocalDate newCheckIn, LocalDate newCheckOut) {
		try (Session session = sessionFactory.openSession()) {
			session.beginTransaction();
			Booking booking = session.get(Booking.class, bookingIdToUpdate);
			if (booking != null) {
				booking.setCheckIn(newCheckIn);
				booking.setCheckOut(newCheckOut);
				// Recalculate price based on new dates
				booking.setTotalPrice(booking.calculateTotalPrice());
				session.getTransaction().commit();
				return true;
			}
			return false; // Booking not found
		}
	}
}
