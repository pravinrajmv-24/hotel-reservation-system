package com.hrs; // Defines the package for the Booking class

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import jakarta.persistence.*; // Imports JPA annotations for ORM mapping

/*
 * Entity class representing a room booking.
 * Maps to the 'booking' table in the database.
 */
@Entity
@Table(name = "booking")
public class Booking {

	// Unique identifier for each booking (Primary Key).
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	// Room associated with this booking (Many-to-One relationship).
	@ManyToOne
	@JoinColumn(name = "room_id")
	private Room room;

	// Customer who made the booking (Many-to-One relationship).
	@ManyToOne
	@JoinColumn(name = "customer_id")
	private Customer customer;

	// Check-in date for the booking.
	private LocalDate checkIn;

	// Check-out date for the booking.
	private LocalDate checkOut;

	// Total cost for the entire stay duration.
	private double totalPrice;

	// Getter for booking ID.
	public int getId() {
		return id;
	}

	// Setter for booking ID.
	public void setId(int id) {
		this.id = id;
	}

	// Getter for associated room.
	public Room getRoom() {
		return room;
	}

	// Setter for associated room.
	public void setRoom(Room room) {
		this.room = room;
	}

	// Getter for associated customer.
	public Customer getCustomer() {
		return customer;
	}

	// Setter for associated customer.
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	// Getter for check-in date.
	public LocalDate getCheckIn() {
		return checkIn;
	}

	// Setter for check-in date.
	public void setCheckIn(LocalDate checkIn) {
		this.checkIn = checkIn;
	}

	// Getter for check-out date.
	public LocalDate getCheckOut() {
		return checkOut;
	}

	// Setter for check-out date.
	public void setCheckOut(LocalDate checkOut) {
		this.checkOut = checkOut;
	}

	// Getter for total price.
	public double getTotalPrice() {
		return totalPrice;
	}

	// Setter for total price.
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	/*
	 * Calculates the total price of the stay based on duration and room's price per
	 * night.
	 * 
	 * @return total booking cost
	 */
	public double calculateTotalPrice() {
		long numberOfNights = ChronoUnit.DAYS.between(checkIn, checkOut);
		return numberOfNights * room.getPricePerNight();
	}

	/*
	 * Returns a string representation of the booking instance.
	 */
	@Override
	public String toString() {
		return "Booking [id=" + id + ", room=" + room + ", customer=" + customer + ", checkIn=" + checkIn
				+ ", checkOut=" + checkOut + ", totalPrice=" + totalPrice + "]";
	}
}
